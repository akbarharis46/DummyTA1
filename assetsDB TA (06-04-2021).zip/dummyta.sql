#
# TABLE STRUCTURE FOR: barang
#

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(255) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  `total` int(11) NOT NULL,
  PRIMARY KEY (`id_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `barang` (`id_barang`, `nama_kategori`, `nama_barang`, `tanggal`, `total`) VALUES ('11', 'Produksi', 'Kardus', '2021-03-29', '25');
INSERT INTO `barang` (`id_barang`, `nama_kategori`, `nama_barang`, `tanggal`, `total`) VALUES ('12', 'Produksi', 'Kardus', '2021-03-29', '1234567');
INSERT INTO `barang` (`id_barang`, `nama_kategori`, `nama_barang`, `tanggal`, `total`) VALUES ('13', 'Produksi1', 'Kardus', '2021-04-04', '1234');


#
# TABLE STRUCTURE FOR: detail_barang
#

DROP TABLE IF EXISTS `detail_barang`;

CREATE TABLE `detail_barang` (
  `id_detailbarang` int(50) NOT NULL AUTO_INCREMENT,
  `total_stock` varchar(255) NOT NULL,
  PRIMARY KEY (`id_detailbarang`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `detail_barang` (`id_detailbarang`, `total_stock`) VALUES ('1', '2345');


#
# TABLE STRUCTURE FOR: detail_pengiriman
#

DROP TABLE IF EXISTS `detail_pengiriman`;

CREATE TABLE `detail_pengiriman` (
  `id_detailpengiriman` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id_detailpengiriman`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: detail_produksi
#

DROP TABLE IF EXISTS `detail_produksi`;

CREATE TABLE `detail_produksi` (
  `id_detailproduksi` int(255) NOT NULL AUTO_INCREMENT,
  `tanggal` varchar(255) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `total_digunakan` int(255) NOT NULL,
  `sisa_stock` int(255) NOT NULL,
  PRIMARY KEY (`id_detailproduksi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: kategori
#

DROP TABLE IF EXISTS `kategori`;

CREATE TABLE `kategori` (
  `id_kategori` int(50) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(255) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES ('6', 'Produksi1');
INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES ('7', 'Pengiriman');
INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES ('9', 'Kebersihan');


#
# TABLE STRUCTURE FOR: login
#

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `level` enum('admin','Staff Produksi','Staff Pengiriman','Staff Gudang') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `login` (`id`, `nama`, `username`, `password`, `level`) VALUES ('17', 'haris46', 'admin', 'admin', 'admin');
INSERT INTO `login` (`id`, `nama`, `username`, `password`, `level`) VALUES ('24', 'produksi', 'produksi', '1234', 'Staff Produksi');
INSERT INTO `login` (`id`, `nama`, `username`, `password`, `level`) VALUES ('25', 'pengiriman', 'pengiriman', '1234', 'Staff Pengiriman');
INSERT INTO `login` (`id`, `nama`, `username`, `password`, `level`) VALUES ('26', 'Gudang', 'gudang', '1234', 'Staff Gudang');


#
# TABLE STRUCTURE FOR: pengiriman
#

DROP TABLE IF EXISTS `pengiriman`;

CREATE TABLE `pengiriman` (
  `id_pengiriman` int(255) NOT NULL AUTO_INCREMENT,
  `nama_pengirim` varchar(255) NOT NULL,
  `nomorhp` varchar(255) NOT NULL,
  `tujuan` varchar(255) NOT NULL,
  `jumlah` varchar(255) NOT NULL,
  `jenis_kendaraan` varchar(255) NOT NULL,
  `nomor_kendaraan` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `status_pengiriman` varchar(255) NOT NULL,
  PRIMARY KEY (`id_pengiriman`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `pengiriman` (`id_pengiriman`, `nama_pengirim`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `status_pengiriman`) VALUES ('14', 'Haris', '', 'sdasd', '23', 'sd', '13413', '2021-04-01', 'Proses Pengiriman');
INSERT INTO `pengiriman` (`id_pengiriman`, `nama_pengirim`, `nomorhp`, `tujuan`, `jumlah`, `jenis_kendaraan`, `nomor_kendaraan`, `tanggal`, `status_pengiriman`) VALUES ('17', 'loki', '0256123', 'malang', '22', 'Truck', 'P092L', '2021-04-04', 'proses');


#
# TABLE STRUCTURE FOR: produksi
#

DROP TABLE IF EXISTS `produksi`;

CREATE TABLE `produksi` (
  `id_produksi` int(255) NOT NULL AUTO_INCREMENT,
  `nama_staff` varchar(255) NOT NULL,
  `shift` varchar(255) NOT NULL,
  `jumlah_produksi` int(255) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  PRIMARY KEY (`id_produksi`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `produksi` (`id_produksi`, `nama_staff`, `shift`, `jumlah_produksi`, `tanggal`) VALUES ('2', 'Haris', 'shift1', '8888', '2021-03-29');
INSERT INTO `produksi` (`id_produksi`, `nama_staff`, `shift`, `jumlah_produksi`, `tanggal`) VALUES ('4', 'Haris2e2e', 'shift2', '9062', '2021-03-30');
INSERT INTO `produksi` (`id_produksi`, `nama_staff`, `shift`, `jumlah_produksi`, `tanggal`) VALUES ('5', 'Haris2e12', 'shift3', '900', '2021-03-30');
INSERT INTO `produksi` (`id_produksi`, `nama_staff`, `shift`, `jumlah_produksi`, `tanggal`) VALUES ('6', 'Haris', 'shift1', '906', '2021-03-23');
INSERT INTO `produksi` (`id_produksi`, `nama_staff`, `shift`, `jumlah_produksi`, `tanggal`) VALUES ('9', 'zaman23', 'shift1', '906', '2021-03-19');
INSERT INTO `produksi` (`id_produksi`, `nama_staff`, `shift`, `jumlah_produksi`, `tanggal`) VALUES ('10', 'zaman14124', 'shift1', '906', '2021-04-16');


